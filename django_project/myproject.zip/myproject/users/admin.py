from django.contrib import admin
from .models import Adduser
# Register your models here.

admin.site.register(Adduser)
