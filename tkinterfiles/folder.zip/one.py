

print("hello world")
