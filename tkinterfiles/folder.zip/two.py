

a = int(input("\n Enter your name : "))
b = int(input("\n Enter your class : "))
print(a+b)
